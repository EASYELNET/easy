# api-ai-kik-bot
Kik bot SDK for Api.ai

[![Deploy to Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)