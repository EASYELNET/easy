# apiai-skype-bot

Before you start the bot you need install the dependencies using 
`npm install`.

Make sure you defined you environment variables APP_ID and APP_SECRET and 
that they contain MSA OAuth credentials.

You can start the bot with `node app.js`. By default the server will
be listening on port 5000.
So service endpoint will be "https://example.com:5000/chat"

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)
